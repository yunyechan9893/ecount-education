import { SpecificationController } from "./controllers.js";

const PAGE_LIMIT = 10;
const CREATE_TYPE = 'CREATE';
const MODIFICAION_TYPE = 'MODIFICATION';
let actionStatus = CREATE_TYPE;
let pageStatus = PAGE_LIMIT;

const specificationController = new SpecificationController();

document.addEventListener('DOMContentLoaded', () => {

    const url = new URL(window.location.href);
    const params = new URLSearchParams(url.search);
    const searchedItem = params.get('searchedItem');

    if (searchedItem) {

        const itemList = JSON.parse(searchedItem);

        console.log(itemList)
        let itemLabel = ''
        itemList.forEach(item => {
            itemLabel += `<${item.itemCode}(${item.itemName})>`
        });

        const keywordTextBox = document.querySelector('#keyword');
        keywordTextBox.value = itemLabel;
    }

    const path = window.location.pathname;
    if (path === '/sale/modification') {
        const numberTextBox = document.querySelector('#number');
        const codeTextBox = document.querySelector('#item-code')
    
        numberTextBox.hidden = false;
        codeTextBox.disabled = true;

        actionStatus = MODIFICAION_TYPE
    }
    
    eventListener()

    // 화면 리로드 이벤트
    window.addEventListener('message', function(event) {
        if (event.data.type === 'refresh-sales-input') {
            // 현재 URL 가져오기
            const url = new URL(window.location.href);
    
            // URLSearchParams 객체 생성
            const params = new URLSearchParams(url.search);
    
            // itemList 초기화 및 데이터 추가
            const itemList = [];
            event.data.search.forEach(data => {
                itemList.push({ itemCode: data.itemCode, itemName: data.itemName });
            });
    
            // itemList를 JSON 문자열로 변환하여 쿼리 파라미터로 추가
            params.set('searchedItem', JSON.stringify(itemList));
    
            // URLSearchParams 객체를 URL에 반영
            url.search = params.toString();
    
            // 새 URL로 리디렉션
            window.location.href = url.toString();
        }
    });
})

function eventListener() {
    const searchButton = document.querySelector('#search');
    searchButton.addEventListener('click', () => {
        openPopup(`/sales/search?page=10`, 1000, 600)
    })

    const savingButton = document.querySelector('#save')
    savingButton.addEventListener('click', () => {
        const yearSelector = document.querySelector('#year');
        const monthSelector = document.querySelector('#month');
        const daySelector = document.querySelector('#day');

        const selectedYearOption = yearSelector.options[yearSelector.selectedIndex].value;
        const selectedMonthOption = monthSelector.options[monthSelector.selectedIndex].value;
        const selectedDayOption = daySelector.options[daySelector.selectedIndex].value;

        const date = selectedYearOption + "-" + selectedMonthOption + "-" + selectedDayOption;

        console.log(date);
        const keywordTextBox = document.querySelector('#keyword');
        const quantityTextBox = document.querySelector('#quantity');
        const priceTextBox = document.querySelector('#price');
        const briefsTextBox = document.querySelector('#briefs');

        if (selectedYearOption == null && selectedYearOption == '') {
            alert('연도를 입력하세요')
            return
        } else if (selectedMonthOption == null && selectedMonthOption == '' ) {
            alert('월을 입력하세요') 
            return
        } else if (selectedDayOption == null && selectedDayOption == '' ) {
            alert('일을 입력하세요') 
            return
        } if (keywordTextBox.value.trim() === '') {
            alert('품목을 입력하세요');
            return;
        } else if (quantityTextBox.value.trim() === '') {
            alert('수량을 입력하세요');
            return;
        } else if (priceTextBox.value.trim() === '') {
            alert('가격을 입력하세요');
            return;
        }

        if (actionStatus === MODIFICAION_TYPE) {
            // const isAlter = itemController.alter(itemCode.value, itemName.value)

            // if (!isAlter) {
            //     console.log('품목 코드가 올바르지 않습니다');
            //     return;
            // }
        } else {

            if (keywordTextBox.value.includes('<') && keywordTextBox.value.includes('>')) {
                parseItemList(
                    date,
                    keywordTextBox.value,
                    quantityTextBox.value,
                    priceTextBox.value,
                    briefsTextBox.value
                )
            } else {
                alert("검색을 통해 아이템을 선택하세요")
                return
            }
            
        }

        excuteRefreshClose()
    })



    const rewriteButton = document.querySelector('#rewrite');
    rewriteButton.addEventListener('click', () => {
        const keywordTextBox = document.querySelector('#keyword');
        const quantityTextBox = document.querySelector('#quantity');
        const priceTextBox = document.querySelector('#price');
        const briefsTextBox = document.querySelector('#briefs');

        keywordTextBox.value = '';
        quantityTextBox.value = '';
        priceTextBox.value = '';
        briefsTextBox.value = '';
    })

    const closeButton = document.querySelector('#close');
    closeButton.addEventListener('click', () => window.close())
    
}

const parseItemList = (date, input, quantity, price, briefs) => {
    // 정규 표현식을 사용하여 <itemCode(itemName)> 형태의 패턴을 추출합니다.
    const regex = /<(\d+)\((\d+)\)>/g;
    let match;

    // 정규 표현식을 사용하여 문자열에서 패턴을 모두 추출합니다.
    while ((match = regex.exec(input)) !== null) {
        const itemCode = parseInt(match[1], 10);   // itemCode는 첫 번째 캡처 그룹
        const itemName = parseInt(match[2], 10);   // itemName은 두 번째 캡처 그룹

        specificationController.push(
            date,
            itemCode,
            itemName,
            quantity,
            price,
            briefs
        )
    }
};

function openPopup(url, x, y) {
    window.open(url, '_blank', `width=${x},height=${y}`); // 팝업 창 열기
}

function excuteRefreshClose() {
    const message = {
        type: 'refresh-sales-inquiry'
    };

    window.opener.postMessage(message, '*');
    window.close()
}